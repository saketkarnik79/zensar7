﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CS_DemoThreadSynchronization
{
    internal class Program
    {
        private static readonly object _lock = new object();
        static int counter = 0;
        static Mutex mutex = new Mutex();

        static void IncrementCounter()
        {
            for (int i = 0; i < 1000; i++)
            {
                //lock (_lock)
                //{
                //    counter++;
                //}
                //Monitor.Enter(_lock);

                //try
                //{
                //    counter++;
                //}
                //finally
                //{
                //    Monitor.Exit(_lock);
                //}

                mutex.WaitOne(); //Wait until the mutex is available
                try
                {
                    counter++;
                }
                finally
                {
                    mutex.ReleaseMutex();
                }
            }
        }

        static void Main(string[] args)
        {
            Thread t1 = new Thread(IncrementCounter);
            Thread t2 = new Thread(IncrementCounter);
            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();

            Console.WriteLine($"Final Counter: {counter}");
            Console.WriteLine("Program completed...");

            Console.ReadKey();
        }
    }
}
