﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoDelegates
{
    //internal delegate void MyDelegate(string message);
    internal delegate void ProcessAction(int value);

    internal class Program
    {
        static void PrintMessage(string message)
        {
            Console.WriteLine(message);
        }

        static void ProcessNumbers(int number, ProcessAction action)
        {
            //Pre code
            action?.Invoke(number);
            //Post Code
        }

        //static void PrintSquare(int number)
        //{
        //    Console.WriteLine($"Square of {number}: {number * number}");
        //}

        //static void PrintCube(int number)
        //{
        //    Console.WriteLine($"Cube of {number}: {number * number * number}");
        //}

        //static void PrintSquareRoot(int number)
        //{
        //    Console.WriteLine($"Square Root of {number}: {Math.Sqrt(number)}");
        //}

        static void Main(string[] args)
        {
            //MyDelegate del = new MyDelegate(PrintMessage);
            //del?.Invoke("Hello from Delegate!");

            //ProcessNumbers(25, new ProcessAction(PrintSquare));
            //ProcessNumbers(25, PrintCube);
            //ProcessNumbers(25, PrintSquareRoot);

            //ProcessNumbers(25, delegate (int number)
            //{
            //    Console.WriteLine($"Square of {number}: {number * number}");
            //});

            //ProcessNumbers(25, delegate (int number)
            //{
            //    Console.WriteLine($"Cube of {number}: {number * number * number}");
            //});

            //ProcessNumbers(25, delegate (int number)
            //{
            //    Console.WriteLine($"Square Root of {number}: {Math.Sqrt(number)}");
            //});

            ProcessNumbers(25, (number) =>
            {
                Console.WriteLine($"Square of {number}: {number * number}");
            });

            ProcessNumbers(25, (number) =>
            {
                Console.WriteLine($"Cube of {number}: {number * number * number}");
            });

            ProcessNumbers(25, (number) =>
            {
                Console.WriteLine($"Square Root of {number}: {Math.Sqrt(number)}");
            });

            Console.ReadKey();
        }
    }
}
