//using System;
using static System.Console;
//namespace CS_DemoHelloWorld;
namespace CS_DemoHelloWorld
{
	class Program
	{
		static void Main(string[] args)
		{
			string name = string.Empty;//""
			if(args.Length > 0 && !string.IsNullOrEmpty(args[0]))
			{
				name = args[0];
				WriteLine($"Hello {name}!");
			}
			else
			{
				WriteLine($"Hello World!");
			}
			// Write("Enter your Name: ");
			// name = ReadLine();
			//System.Console.WriteLine("Hello World!");
			//WriteLine("Hello {0}!", name);
			//WriteLine($"Hello {name}!");
		}
	}
}