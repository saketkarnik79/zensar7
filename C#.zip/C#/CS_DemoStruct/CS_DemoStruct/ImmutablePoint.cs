﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoStruct
{
    internal struct ImmutablePoint
    {
        public readonly int X;
        public readonly int Y;

        public ImmutablePoint(int x, int y)
        {
            X = x;
            Y = y;
        }

        public ImmutablePoint MoveBy(int deltaX, int deltaY)
        {
            return new ImmutablePoint(X + deltaX, Y + deltaY);
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }
    }
}
