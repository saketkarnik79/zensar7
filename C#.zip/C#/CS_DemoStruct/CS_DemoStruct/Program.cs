﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoStruct
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Point p1 = new Point(3, 4);
            //Point p2 = new Point(7, 1);
            //Console.WriteLine($"Point 1: {p1}");
            //Console.WriteLine($"Point 2: {p2}");
            //double distance=p1.DistanceTo(p2); ;
            //Console.WriteLine($"Distance between {p1} and {p2} is: {distance}");
            //Point p3=new Point();
            //Console.WriteLine(p3);

            ImmutablePoint p1= new ImmutablePoint(3,4);
            ImmutablePoint p2 = p1.MoveBy(5, -3);
            Console.WriteLine($"Original point: {p1}");
            Console.WriteLine($"Moved point: {p2}");
            Console.ReadKey();
        }
    }
}
