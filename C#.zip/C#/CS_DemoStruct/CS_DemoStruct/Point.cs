﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoStruct
{
    internal struct Point
    {
        public int X;
        public int Y;

        //public Point()
        //{
        //    X = 0;
        //    Y = 0;
        //}

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }

        public double DistanceTo(Point anotherPoint)
        {
            int deltaX=X-anotherPoint.X;
            int deltaY=Y-anotherPoint.Y;
            return Math.Sqrt(deltaX * deltaX + deltaY * deltaY);
        }

        public override string ToString()
        {
            return $"({X}, {Y})";
        }
    }
}
