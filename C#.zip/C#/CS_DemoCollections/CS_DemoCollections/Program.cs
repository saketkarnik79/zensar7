﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoCollections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //DemoArrayList();
            //StackDemo();
            //QueueDemo();
            //HashTableDemo();

            //DemoList();
            //GStackDemo();
            //GQueueDemo();
            //DictionaryDemo();
            //SortedDictionaryDemo();

            Console.ReadKey();
        }

        private static void SortedDictionaryDemo()
        {
            SortedDictionary<int, string> ht = new SortedDictionary<int, string>();
            ht.Add(3, "Three");
            ht.Add(1, "One");
            ht.Add(2, "Two");
            //ht.Reverse();

            Console.WriteLine(ht[1]);

            foreach (var key in ht.Keys)
            {
                Console.WriteLine($"Key: {key}, Value: {ht[key]}");
            }
        }

        private static void DictionaryDemo()
        {
            Dictionary<int, string> ht = new Dictionary<int, string>(3);
            ht.Add(1, "One");
            ht.Add(2, "Two");
            ht.Add(3, "Three");

            Console.WriteLine(ht[1]);

            foreach (var key in ht.Keys)
            {
                Console.WriteLine($"Key: {key}, Value: {ht[key]}");
            }
        }

        private static void GQueueDemo()
        {
            Queue<int> queue = new Queue<int>(3);
            queue.Enqueue(1);
            queue.Enqueue(2);
            queue.Enqueue(3);
            Console.WriteLine($"Peek: {queue.Peek()}");
            Console.WriteLine($"Dequeue: {queue.Dequeue()}");

            Console.WriteLine($"Peek: {queue.Peek()}");
        }

        private static void GStackDemo()
        {
            Stack<int> stk = new Stack<int>(3);
            stk.Push(1);
            stk.Push(2);
            stk.Push(3);
            Console.WriteLine($"Peek: {stk.Peek()}");
            Console.WriteLine($"Pop: {stk.Pop()}");

            Console.WriteLine($"Peek: {stk.Peek()}");
        }

        private static void DemoList()
        {
            List<int> list = new List<int>(3);
            //List<int> list2=new List<int>(3);
            //List<string> list3=new List<string>(3);

            list.Add(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            //list.Add("Five");
            //list.Add(7.34d);
            int sum = 0;
            foreach (var item in list)
            {
                sum += item;
                Console.WriteLine(item);
            }

            list[2] = 6;
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
        }

        private static void HashTableDemo()
        {
            Hashtable ht = new Hashtable(3);
            ht.Add(1, "One");
            ht.Add(2, "Two");
            ht.Add(3, "Three");

            Console.WriteLine(ht[1]);

            foreach (var key in ht.Keys)
            {
                Console.WriteLine($"Key: {key}, Value: {ht[key]}");
            }
        }

        private static void QueueDemo()
        {
            Queue queue = new Queue(3);
            queue.Enqueue(1);
            queue.Enqueue(2);
            queue.Enqueue(3);
            Console.WriteLine($"Peek: {queue.Peek()}");
            Console.WriteLine($"Dequeue: {queue.Dequeue()}");

            Console.WriteLine($"Peek: {queue.Peek()}");
        }

        private static void StackDemo()
        {
            Stack stk = new Stack(3);
            stk.Push(1);
            stk.Push(2);
            stk.Push(3);
            Console.WriteLine($"Peek: {stk.Peek()}");
            Console.WriteLine($"Pop: {stk.Pop()}");

            Console.WriteLine($"Peek: {stk.Peek()}");
        }

        private static void DemoArrayList()
        {
            ArrayList list = new ArrayList(3);
            list.Add(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            //list.Add("Five");
            //list.Add(7.34d);
            int sum = 0;
            foreach (var item in list)
            {
                sum += Convert.ToInt32(item);
                Console.WriteLine(item);
            }

            list[2] = 6;
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
        }
    }
}
