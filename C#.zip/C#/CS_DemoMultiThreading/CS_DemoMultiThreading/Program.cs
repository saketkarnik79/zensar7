﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace CS_DemoMultiThreading
{
    internal class Program
    {
        static void PrintNumbers()
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine($"Worker Thread Id: {Thread.CurrentThread.ManagedThreadId}");
                Console.WriteLine($"Worker Thread: {i}");
                Thread.Sleep(1000);
            }
        }

        static void PrintNumbersWithParameter(object count)
        {
            for (int i = 1; i <= Convert.ToInt32(count); i++)
            {
                Console.WriteLine($"Worker Thread Id: {Thread.CurrentThread.ManagedThreadId}");
                Console.WriteLine($"Worker Thread: {i}");
                Thread.Sleep(1000);
            }
        }

        static void Main(string[] args)
        {
            //Thread t1=new Thread(PrintNumbers);
            //t1.Start();

            //Thread t1 = new Thread(PrintNumbersWithParameter);
            //t1.Start(10);

            //for (int i = 1; i <= 5; i++)
            //{
            //    Console.WriteLine($"Main Thread Id: {Thread.CurrentThread.ManagedThreadId}");
            //    Console.WriteLine($"Main Thread: {i}");
            //    Thread.Sleep(1000);
            //}

            ThreadPool.QueueUserWorkItem(PrintNumbersWithParameter, 15);
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine($"Main Thread Id: {Thread.CurrentThread.ManagedThreadId}");
                Console.WriteLine($"Main Thread: {i}");
                Thread.Sleep(1000);
            }

            Console.WriteLine("Program completed...");
            Console.ReadKey();
        }
    }
}
