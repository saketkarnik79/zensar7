﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoEvents
{
    internal delegate void Notify(string message);

    internal class Process
    {
        public event Notify ProcessCompleted;

        public void StartProcess()
        {
            Console.WriteLine("Process started...");
            OnProcessCompleted("Process completed successfully...");
        }

        protected virtual void OnProcessCompleted(string message)
        {
            ProcessCompleted?.Invoke(message);
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Process process = new Process();
            process.ProcessCompleted += Process_ProcessCompleted;
            process.StartProcess();
            Console.ReadKey();
        }

        private static void Process_ProcessCompleted(string message)
        {
            Console.WriteLine(message);
        }
    }
}
