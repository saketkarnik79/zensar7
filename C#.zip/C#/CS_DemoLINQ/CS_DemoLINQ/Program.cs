﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoLINQ
{
    internal class Program
    {
        static void Example1()
        {
            List<int> numbers=new List<int>() { 10, 45, 15, 32, 55, 17, 8 };
            //Get all numbers unordered
            //var result = from n in numbers
            //             select n;

            ////Get all numbers ordered
            //var result = from n in numbers
            //             orderby n
            //             select n;

            //Get all numbers greater than 15 ordered
            var result = from n in numbers
                         where n > 15
                         orderby n
                         select n;

            foreach (var n in result)
            {
                Console.WriteLine(n);
            }
        }

        static void Example2()
        {
            List<int> numbers = new List<int>() { 10, 45, 15, 32, 55, 17, 8 };
            //Get all numbers unordered
            //var result = numbers.Select((n)=>n);

            //Get all numbers ordered
            //var result = numbers.OrderBy((n)=>n).Select((n)=>n);

            //Get all numbers greater than 15 ordered
            var result = numbers.Where((n) => n > 15).OrderBy((n) => n).Select((n) => n);

            foreach (var n in result)
            {
                Console.WriteLine(n);
            }
        }

        static void Example3()
        {
            List<string> names = new List<string>() { "James", "John", "Alice", "Bob", "Charlie", "Anna" };
            //var result=from name in names
            //           where name.StartsWith("A")
            //           select name;
            var result = names
                        .Where((name) => name.StartsWith("A"))
                        .Select((name) => name);
            foreach (var name in result)
            {
                Console.WriteLine(name);
            }
        }

        static void Example4()
        {
            List<Student> students = new List<Student>()
            {
                new Student() { Id = 1, Name = "James", Age = 23 },
                new Student() { Id = 2, Name = "John", Age = 18 },
                new Student() { Id = 3, Name = "Alice", Age = 22 },
                new Student() { Id = 4, Name = "Bob", Age = 21 },
                new Student() { Id = 5, Name = "Charlie", Age = 19 }
            };
            var result = from student in students
                         where student.Age > 20
                         select new { student.Name, student.Age };
            foreach (var student in result)
            {
                Console.WriteLine($"Name: {student.Name}, Age: {student.Age}");
            }
        }

        static void Example5()
        {
            List<Student> students = new List<Student>()
            {
                new Student() { Id = 1, Name = "James", Age = 22 },
                new Student() { Id = 2, Name = "John", Age = 18 },
                new Student() { Id = 3, Name = "Alice", Age = 22 },
                new Student() { Id = 4, Name = "Bob", Age = 21 },
                new Student() { Id = 5, Name = "Charlie", Age = 18 }
            };
            //var result = from student in students
            //             group student by student.Age into sg
            //             select sg;
            var result = students
                        .GroupBy((student) => student.Age)
                        .Select((sg) => sg);

            foreach (var group in result)
            {
                Console.WriteLine($"Age group: {group.Key}");
                foreach (var student in group)
                {
                    Console.WriteLine($"\tName: {student.Name}");
                }
            }
        }

        static void Example6()
        {
            List<Student> students = new List<Student>()
            {
                new Student() { Id = 1, Name = "James", Age = 23 },
                new Student() { Id = 2, Name = "John", Age = 18 },
                new Student() { Id = 3, Name = "Alice", Age = 22 },
                new Student() { Id = 4, Name = "Bob", Age = 21 },
                new Student() { Id = 5, Name = "Charlie", Age = 19 }
            };

            List<Course> courses = new List<Course>()
            {
                new Course() { CourseId = 1, CourseName = "Maths", StudentId = 1 },
                new Course() { CourseId = 2, CourseName = "Physics", StudentId = 2 },
                new Course() { CourseId = 3, CourseName = "Chemistry", StudentId = 3 },
                new Course() { CourseId = 4, CourseName = "Biology", StudentId = 1 },
                new Course() { CourseId = 5, CourseName = "Economics", StudentId = 6 }
            };

            var result = from student in students
                         join course in courses
                         on student.Id equals course.StudentId
                         select new { student.Name, course.CourseName };
            foreach (var item in result)
            {
                Console.WriteLine($"Student: {item.Name}, Course: {item.CourseName}");
            }
        }

        static void Main(string[] args)
        {
            //Example1();
            //Example2();
            //Example3();
            //Example4();
            //Example5();
            Example6();

            Console.ReadKey();
        }
    }
}
