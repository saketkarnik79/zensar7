﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoSealed.Banking
{
    internal class BankAccount
    {
        protected double balance;

        public BankAccount(double initialBalance)
        {
            balance = initialBalance;
        }

        public virtual void Deposit(double amount)
        {
            if (amount > 0)
            {
                balance += amount;
            }
            else
            {
                Console.WriteLine("Deposit amount must be positive.");
            }
        }

        public virtual void Withdraw(double amount)
        {
            if ( amount>0 && amount<=balance)
            {
                balance -= amount;
            }
            else
            {
                Console.WriteLine("Insufficient funds or invalid amount.");
            }
        }

        public double Balance
        {
            get
            {
                return balance;
            }
        }
    }

    internal class LoanAccount:BankAccount
    {
        public LoanAccount(double initialBalance):base(initialBalance)
        {
            
        }

        public sealed override void Deposit(double amount)
        {
            base.Deposit(amount);
        }

        public sealed override void Withdraw(double amount)
        {
            base.Withdraw(amount);
        }
    }

    internal class MortgageLoanAccount:LoanAccount
    {
        public MortgageLoanAccount(double initialBalance):base(initialBalance)
        {
            
        }
    }
}
