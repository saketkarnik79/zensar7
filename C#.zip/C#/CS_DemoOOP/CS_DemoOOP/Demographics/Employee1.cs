﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Demographics
{
    internal partial class Employee
    {
        private int employeeId;
        private string firstName;
        private string lastName;

        public Employee(int employeeId, string firstName, string lastName)
        {
            this.employeeId = employeeId;
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public string GetFullName()
        {
            return $"{this.firstName} {this.lastName}";
        }

        //public partial void DisplayInfo();
    }
}
