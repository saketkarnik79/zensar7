﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Demographics
{
    partial class Employee
    {
        public void PrintEmployeeDetails()
        {
            Console.WriteLine($"EmployeeID: {employeeId}\nFull Name: {GetFullName()}");
        }

        public void DisplayInfo()
        {
            Console.WriteLine("Displaying employee details using a partial method.");
        }
    }
}
