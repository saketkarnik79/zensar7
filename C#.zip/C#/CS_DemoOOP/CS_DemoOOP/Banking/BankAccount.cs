﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Banking
{
    internal class BankAccount
    {
        private string _accountHolder;
        private decimal _balance;
        private string _accountNumber;

        private static int _accountNumberSeed = 1234567890;

        public BankAccount(string accountHolder, decimal initialBalance)
        {
            _accountHolder = accountHolder;
            _balance = initialBalance;
            _accountNumber=_accountNumberSeed.ToString();
            _accountNumberSeed++;
        }

        public string AccountNumber 
        { 
            get
            {
                return _accountNumber;
            }
        }

        public string AccountHolder
        {
            get
            {
                return _accountHolder;
            }
        }

        public decimal Balance
        {
            get
            {
                return _balance;
            }
        }

        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Deposit amount must be greater than zero.");
            }
            _balance += amount;
            Console.WriteLine($"Deposited: {amount:C}. New Balance: {_balance:C}");
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Deposit amount must be greater than zero.");
            }
            if (amount > _balance)
            {
                throw new InvalidOperationException("Insufficient funds.");
            }
            _balance -= amount;
            Console.WriteLine($"Withdrew: {amount:C}. New Balance: {_balance:C}");
        }

        public override string ToString()
        {
            return $"Account Holder: {_accountHolder}\nAccount Number: {_accountNumber}\nBalance: {_balance}";
        }
    }
}
