﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Banking
{
    public class SavingsAccount : BankAccountV2
    {
        public SavingsAccount(string accountHolder, decimal initialBalance): base(accountHolder, initialBalance) 
        {
            SetAccountType("Savings");
        }

        public void ApplyInterest(decimal rate)
        {
            decimal interest = (Balance * rate) / 100;
            Deposit(interest);
            Console.WriteLine($"Applied {rate}% interest. New balance is: {Balance:C}");
        }

        public void DisplayMinimumBalance()
        {
            Console.WriteLine($"The minimum balance for this account is: {MinimumBalance:C}");
        }
    }
}
