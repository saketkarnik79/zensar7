﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Banking
{
    public class BankAccountV2
    {
        private decimal _balance;
        private string _accountHolder;

        public string AccountNumber { get; private set; }

        protected string AccountType { get; set; }

        internal static int TransactionCount { get; private set; }

        protected internal decimal MinimumBalance { get; set; }

        internal decimal Balance
        {
            get
            {
                return _balance;
            }
        }

        public BankAccountV2(string accountHolder, decimal initialBalance)
        {
            _accountHolder = accountHolder;
            _balance = initialBalance;
            AccountNumber=Guid.NewGuid().ToString();
            TransactionCount = 0;
            MinimumBalance = 500;
        }

        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Deposit amount must be greater than zero.");
            }
            _balance += amount;
            TransactionCount++;
            Console.WriteLine($"Deposited: {amount:C}. New Balance: {_balance:C}");
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentOutOfRangeException(nameof(amount), "Deposit amount must be greater than zero.");
            }
            if (amount > _balance)
            {
                throw new InvalidOperationException("Insufficient funds.");
            }
            _balance -= amount;
            TransactionCount++;
            Console.WriteLine($"Withdrew: {amount:C}. New Balance: {_balance:C}");
        }

        private void CheckBalance()
        {
            Console.WriteLine($"Current balance is: {_balance:C}");
        }

        internal void ShowAccountHolder()
        {
            Console.WriteLine($"Account Holder: {_accountHolder}");
        }

        protected void SetAccountType(string type)
        {
            AccountType = type;
        }

        public void _PrintBalance()
        {
            CheckBalance();
        }
    }
}
