﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Vehicles
{
    internal class Car: Vehicle
    {
        private int numberOfDoors;

        public Car(string make, string model, int year, int numberOfDoors): base(make, model, year)
        {
            this.numberOfDoors = numberOfDoors;
        }

        public override void DisplayInfo()
        {
            Console.WriteLine($"Car: {year} - {make} {model}, Doors: {numberOfDoors}");
        }

        new public void Drive()
        {
            Console.WriteLine("Driving the car smoothly...");
        }

        public void OpenSunRoof()
        {
            Console.WriteLine("Opening the SunRoof...");
        }
    }
}
