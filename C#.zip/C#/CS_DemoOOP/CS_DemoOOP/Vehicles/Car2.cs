﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Vehicles
{
    internal class Car2 : IVehicle
    {
        private int speed;

        public int Speed { get => speed; set => speed = value; }

        public void Start()
        {
            Console.WriteLine("Car started...");
        }

        public void Stop()
        {
            Console.WriteLine("Car stopped...");
        }
    }
}
