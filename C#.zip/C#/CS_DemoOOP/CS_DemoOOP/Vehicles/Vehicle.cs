﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Vehicles
{
    internal class Vehicle
    {
        protected string make;
        protected string model;
        protected int year;

        public Vehicle(string make, string model, int year)
        {
            this.make = make;
            this.model = model;
            this.year = year;
        }

        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Vehicle: {year} - {make} {model}");
        }

        public void Start()
        {
            Console.WriteLine("Vehicle is starting...");
        }

        public  void Drive()
        {
            Console.WriteLine("Driving the vehicle...");
        }
    }
}
