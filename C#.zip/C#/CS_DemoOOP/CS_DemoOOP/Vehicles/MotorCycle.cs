﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Vehicles
{
    internal class MotorCycle: Vehicle
    {
        private bool hasSideCar;

        public MotorCycle(string make, string model, int year, bool hasSideCar): base(make, model, year)
        {
            this.hasSideCar = hasSideCar;
        }

        public override void DisplayInfo()
        {
            string sideCarInfo = hasSideCar ? "with a sidecar" : "without a sidecar";
            Console.WriteLine($"Motorcycle: {year} - {make} {model} - {sideCarInfo}");
        }

        new public  void Drive()
        {
            Console.WriteLine("Riding the motorcycle...");
        }

        public void PopWheelie()
        {
            Console.WriteLine("Popping a wheelie...");
        }
    }
}
