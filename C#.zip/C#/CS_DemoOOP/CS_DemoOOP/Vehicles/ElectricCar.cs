﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Vehicles
{
    internal class ElectricCar : IVehicle, IElectricVehicle
    {
        public int BatteryPercentage { get; set; }
        public int Speed { get; set; }

        public void ChargeBattery()
        {
            BatteryPercentage = 100;
            Console.WriteLine("ELECTRIC CAR BATTERY FULLY CHARGED.");
        }

        public void Start()
        {
            Console.WriteLine("Electric car started.");
        }

        public void Stop()
        {
            Console.WriteLine("Electric car stopped.");
        }
    }
}
