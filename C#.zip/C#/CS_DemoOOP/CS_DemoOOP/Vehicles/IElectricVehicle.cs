﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Vehicles
{
    internal interface IElectricVehicle
    {
        int BatteryPercentage { get; set; }

        void ChargeBattery();
    }
}
