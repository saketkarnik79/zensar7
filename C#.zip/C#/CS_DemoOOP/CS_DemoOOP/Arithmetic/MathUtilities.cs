﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Arithmetic
{
    internal static class MathUtilities
    {
        public static readonly double Pi = (double)22 / (double)7;

        public static int Max(int a, int b)
        {
            return (a > b) ? a : b;
        }

        public static int Factorial(int n)
        {
            if (n < 0)
                throw new ArgumentException("Factorial can't be calculated for negative numbers.");
            int result = 1;
            for (int i = 2; i <= n; i++)
                result *= i;
            return result;
        }

        public static double DegreesToRadians(double degrees)
        {
            return degrees * (Pi / 180);
        }

        static MathUtilities()
        {
            Console.WriteLine("Static constructor called. MathUtilies class initialized.");
        }
    }
}