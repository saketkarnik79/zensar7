﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Shapes
{
    internal class Rectangle: IShape
    {
        private double _length;
        private double _width;

        public Rectangle(double length, double width)
        {
            _length = length;
            _width = width;
        }

        //public override double CalculateArea()
        //{
        //    return _length * _width;
        //}

        public double CalculateArea()
        {
            return _length * _width;
        }

        public double CalculatePerimeter()
        {
            return 2 * (_length + _width);
        }
    }
}
