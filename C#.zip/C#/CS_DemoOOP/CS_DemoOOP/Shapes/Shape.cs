﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoOOP.Shapes
{
    internal abstract class Shape
    {
        public abstract double CalculateArea();

        public void DisplayArea()
        {
            Console.WriteLine($"Thea area of the {this.GetType().Name} is: {CalculateArea()}");
        }
    }
}
