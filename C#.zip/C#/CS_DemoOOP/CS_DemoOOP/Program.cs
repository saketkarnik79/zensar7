﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_DemoOOP.Banking;
using CS_DemoOOP.Arithmetic;
using CS_DemoOOP.Vehicles;
using CS_DemoOOP.Demographics;
using CS_DemoOOP.Shapes;

namespace CS_DemoOOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //BankAccount account = new BankAccount("James", 10000);
            //Console.WriteLine(account);
            //account.Deposit(3000);
            //account.Withdraw(1500);
            //Console.WriteLine(account);

            //BankAccountV2 account = new BankAccountV2("James", 10000);
            //account.Deposit(5000);
            //account._PrintBalance();

            //SavingsAccount savingsAccount = new SavingsAccount("James", 20000);
            //savingsAccount.Deposit(3000);
            //savingsAccount.ApplyInterest(2);
            //savingsAccount.DisplayMinimumBalance();

            //account.ShowAccountHolder();

            //Console.WriteLine(Calc.Add(20,10));
            //Console.WriteLine(Calc.Add(20,10, 5));
            //Console.WriteLine(Calc.Add(20.23d,10.34d));

            //Car myCar = new Car("Toyota", "Camry", 2022, 4);
            //myCar.DisplayInfo();
            //myCar.Start();
            //myCar.Drive();
            //myCar.OpenSunRoof();

            //Console.WriteLine();

            //MotorCycle bike = new MotorCycle("Harley Davidson", "Sportster", 2023, false);
            //bike.DisplayInfo();
            //bike.Start();
            //bike.Drive();
            //bike.PopWheelie();

            //Vehicle myVehicle;

            //myVehicle = new Vehicle("Toyota", "Camry", 2022 );
            //myVehicle.DisplayInfo();
            //myVehicle.Start();
            //myVehicle.Drive();

            //myVehicle = new Car("Toyota", "Camry", 2022, 4);
            //myVehicle.DisplayInfo();
            //myVehicle.Start();
            //(myVehicle as Car).Drive();

            //myVehicle = new MotorCycle("Harley Davidson", "Sportster", 2023, false);
            //myVehicle.DisplayInfo();
            //myVehicle.Start();
            //myVehicle.Drive();

            //Employee emp = new Employee(101, "James", "Bond");
            //emp.DisplayInfo();
            //emp.PrintEmployeeDetails();

            //int max = MathUtilities.Max(10, 20);
            //Console.WriteLine($"Max of 10 and 20: {max}");

            //int factorial = MathUtilities.Factorial(5);
            //Console.WriteLine($"Factorial of 5 is: {factorial}");

            //double radians = MathUtilities.DegreesToRadians(180);
            //Console.WriteLine($"180 degrees in radians: {radians}");

            //Console.WriteLine($"Value of Pi is: {MathUtilities.Pi}");

            //Shape circle = new Circle(5);
            //circle.DisplayArea();

            //Shape rectangle = new Rectangle(10, 20);
            //rectangle.DisplayArea();

            //IShape circle = new Circle(5);
            //IShape rectangle = new Rectangle(7, 4);

            //Console.WriteLine("Circle:");
            //Console.WriteLine($"Area: {circle.CalculateArea()}");
            //Console.WriteLine($"Perimeter: {circle.CalculatePerimeter()}");

            //Console.WriteLine("Rectangle:");
            //Console.WriteLine($"Area: {rectangle.CalculateArea()}");
            //Console.WriteLine($"Perimeter: {rectangle.CalculatePerimeter()}");

            ElectricCar car = new ElectricCar();
            car.Speed = 80;
            car.BatteryPercentage = 50;

            car.Start();
            Console.WriteLine($"Speed: {car.Speed} km/h");

            Console.WriteLine($"Battery: {car.BatteryPercentage}%");

            car.ChargeBattery();
            Console.WriteLine($"Battery after charging: {car.BatteryPercentage}%");

            car.Stop();

            Console.ReadKey();
        }
    }
}
