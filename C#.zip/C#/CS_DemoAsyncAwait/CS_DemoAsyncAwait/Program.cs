﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace CS_DemoAsyncAwait
{
    internal class Program
    {
        static async Task<string> FetchDataAsync()
        {
            using (HttpClient client=new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(
                    "https://jsonplaceholder.typicode.com/posts");
                response.EnsureSuccessStatusCode();
                string data=await response.Content.ReadAsStringAsync();
                return data;
            };
        }

        static async Task Main(string[] args)
        {
            var t1 = Task.Run(() =>
            {
                Console.WriteLine("I'm task.");
                return 2;
            });
            int r = await t1;
            Console.WriteLine(r);

            try
            {
                Console.WriteLine("Starting to fetch data from api...");
                string result = await FetchDataAsync();
                Console.WriteLine("Data fetched successfully...");
                Console.WriteLine(result);
            }
            catch (HttpRequestException ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
            Console.ReadKey();
        }
    }
}
