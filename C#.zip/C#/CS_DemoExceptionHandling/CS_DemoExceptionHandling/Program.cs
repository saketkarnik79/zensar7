﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_DemoExceptionHandling.Exceptions;
using System.IO;

namespace CS_DemoExceptionHandling
{
    internal class Program
    {
        static void ValidateNumber(int number)
        {
            if (number<0)
            {
                throw new NegativeNumberException("Negative numbers are not allowed.");
            }
        }

        static void Main(string[] args)
        {
            //DivideByZeroExceptionExample();
            //MultipleExceptionExample();
            //CustomExceptionExample();
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter("example.txt");
                writer.WriteLine("Writing some text to the file.");
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                    writer.Dispose();
                    Console.WriteLine("File closed.");
                }
            }
            Console.ReadKey();
        }

       private static void CustomExceptionExample()
        {
            int n = 5;
            try
            {
                ValidateNumber(n);
                Console.WriteLine($"{n} is valid.");
            }
            catch (NegativeNumberException ex)
            {
                Console.WriteLine("Error caught & handled.");
                //throw ex;
            }
            finally
            {
                Console.WriteLine("Cleanup completed.");
            }
        }

        private static void MultipleExceptionExample()
        {
            string[] fruits = { "Apple", "Banana", "Orange" };
            try
            {
                Console.WriteLine(fruits[2]);
                int number = int.Parse("ABC");
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Error: Array index is out of bounds.");
                Console.WriteLine($"Exception Mesage: {ex.Message}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Error: Invalid format for number conversion.");
                Console.WriteLine($"Exception Mesage: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: An unexpected error occured.");
                Console.WriteLine($"Exception Mesage: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("Cleanup completed.");
            }
        }

        private static void DivideByZeroExceptionExample()
        {
            int n1 = 10;
            int n2 = 0;
            int result;
            try
            {
                result = n1 / n2;
                Console.WriteLine($"Result: {result}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("Error: Cannot divide by zero.");
                Console.WriteLine($"Exception Message: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Message: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("End of division operation. Doing cleanup.");
            }
        }
    }
}
