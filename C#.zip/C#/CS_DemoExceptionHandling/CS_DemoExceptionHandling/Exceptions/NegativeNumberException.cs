﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoExceptionHandling.Exceptions
{
    internal class NegativeNumberException : ApplicationException
    {
        public NegativeNumberException(string message): base(message)
        {
            //Logging code goes here
            Console.WriteLine($"Error: {message}");
        }
    }
}
