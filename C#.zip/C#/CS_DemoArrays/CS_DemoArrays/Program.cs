﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoArrays
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int[] numbers = new int[5];
            //numbers[0] = 1;
            //numbers[1] = 2;
            //numbers[2] = 3;
            //numbers[3] = 4;
            //int[] numbers = new int[] { 1, 2, 3, 4, 5};
            ////for (int i = 0; i < numbers.GetLength(0); i++)
            ////{
            ////    Console.WriteLine(numbers[i]);
            ////}
            //foreach (int i in numbers)
            //{
            //    Console.WriteLine(i);
            //}

            //int[,] numbers = new int[3, 4];
            //numbers[0, 0] = 1;
            //numbers[0, 1] = 2;
            //numbers[0, 2] = 3;
            //numbers[0, 3] = 4;
            //numbers[1, 0] = 10;
            //numbers[1, 1] = 20;
            //numbers[1, 2] = 30;
            //numbers[1, 3] = 40;
            //numbers[2, 0] = 100;
            //numbers[2, 1] = 200;
            //numbers[2, 2] = 300;
            //numbers[2, 3] = 400;

            //int[,] numbers = {
            //    { 1,2,3,4},
            //    { 10,20,30,40},
            //    { 100,200,300,400}
            //};

            //for (int i = 0; i < numbers.GetLength(0); i++)
            //{
            //    for (int j = 0; j < numbers.GetLength(1); j++)
            //    {
            //        Console.Write($"{numbers[i,j]}, ");
            //    }
            //    Console.WriteLine();
            //}

            char choice='y';
            Random random = new Random(0);
            while (char.ToLower(choice) == 'y')
            {
                Console.Write("Enter the size of array you want to create: ");
                int size=int.Parse(Console.ReadLine());
                int[] numbers= new int[size];
                for (int i = 0;i<numbers.Length;i++)
                {
                    numbers[i] = random.Next(1000);
                }

                foreach (var n in numbers)
                {
                    Console.WriteLine(n);
                }
                Array.Sort(numbers);
                Console.WriteLine("\n\nSorted Array...");
                foreach (var n in numbers)
                {
                    Console.WriteLine(n);
                }
                Array.Reverse(numbers);
                Console.WriteLine("\n\nReversed Array...");
                foreach (var n in numbers)
                {
                    Console.WriteLine(n);
                }

                Console.WriteLine();
                Console.Write("Do you want another array?(<y/n>): ");
                choice = char.Parse(Console.ReadLine());
            } 
            Console.WriteLine("Program completed...");

            Console.ReadKey();
        }
    }
}
