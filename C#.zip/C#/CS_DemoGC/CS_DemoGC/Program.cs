﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoGC
{
    internal class ResourceHolder: IDisposable
    {
        ~ResourceHolder()
        {
            Console.WriteLine("ResourceHolder object is being finalized.");
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Console.WriteLine("ResourceHolder object is being disposed.");
        }
    }

    internal class Program
    {
        static void CreateLargeObject()
        {
            int[] largeArray = new int[100000];
            Console.WriteLine($"Total memory before GC: {GC.GetTotalMemory(false)} bytes");
        }

        static void Main(string[] args)
        {
            //CreateLargeObject();
            //GC.Collect();
            //GC.WaitForPendingFinalizers();
            //Console.WriteLine("Garbage collection done.");
            //Console.WriteLine($"Total memory after GC: {GC.GetTotalMemory(false)} bytes");

            using (ResourceHolder holder = new ResourceHolder())
            {
                //GC.SuppressFinalize( holder );

                //holder.Dispose();
                //holder = null;
                //GC.Collect();
                GC.WaitForPendingFinalizers();
                Console.WriteLine("Garbage collection done without finalizing the object.");
            }

            Console.ReadKey();
        }
    }
}
