﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_DemoIQueryable.Models;
using CS_DemoIQueryable.Data;

namespace CS_DemoIQueryable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var context=new SchoolDbContext())
            {
                IQueryable<Student> studentsQuery = context.Students.Where(s => s.Age > 20);
                
                Console.WriteLine("Students older than 20 (using IQueryable):");
                foreach (var student in studentsQuery)
                {
                    Console.WriteLine($"Student: {student.Name}, Age: {student.Age}");
                }
            }
            Console.ReadKey();
        }
    }
}
