﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using CS_DemoIQueryable.Models;

namespace CS_DemoIQueryable.Data
{
    public class SchoolDbContext:DbContext
    {
        public DbSet<Student> Students { get; set; }

        public SchoolDbContext():base("cs")
        {
            
        }
    }
}
