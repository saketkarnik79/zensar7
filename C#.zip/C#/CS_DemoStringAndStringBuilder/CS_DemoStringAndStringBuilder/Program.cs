﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoStringAndStringBuilder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //string s1 = "Hello";
            //Console.WriteLine(s1);
            //s1 += " World!";
            //Console.WriteLine(s1);
            StringBuilder sb = new StringBuilder("Hello");
            sb.Append(" World!");
            string s1 = sb.ToString();
            Console.WriteLine(s1);

            Console.ReadKey();
        }
    }
}
