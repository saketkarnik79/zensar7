﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CS_DemoTPL
{
    internal class Program
    {
        static void PrintNumbers(string taskName)
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine($"{taskName}: {i}");
                Task.Delay(1000).Wait();
            }
        }

        static void PrintNumbers(CancellationToken token)
        {
            for (int i = 1; i <= 10; i++)
            {
                if (token.IsCancellationRequested)
                {
                    Console.WriteLine("Cancellation requested.");
                    return;
                }
                Console.WriteLine($"Number: {i}");
                Task.Delay(1000).Wait();
            }
        }

        static void Main(string[] args)
        {
            //Task task1 = Task.Run(() => PrintNumbers("Task 1"));
            //Task task2 = Task.Run(() => PrintNumbers("Task 2"));

            //Task.WaitAll(task1, task1);

            //Console.WriteLine("All tasks completed.");

            //int sum = 0;
            //object _lock= new object();

            //for (int i = 1; i <= 10; i++)
            //{
            //    Console.WriteLine($"Processing Number: {i}");
            //    sum += i;
            //    Task.Delay(1000).Wait();
            //}

            //Parallel.For(1, 10000 + 1, (i) => 
            //{
            //    lock (_lock)
            //    {
            //        Console.WriteLine($"Processing Number: {i}, Thread Id: {Thread.CurrentThread.ManagedThreadId}");
            //        sum += i;
            //        Task.Delay(100).Wait();
            //    }
            //});

            //Console.WriteLine($"The sum is: {sum}");

            CancellationTokenSource cts=new CancellationTokenSource();
            Task task = Task.Run(() => PrintNumbers(cts.Token), cts.Token);
            Task.Delay(3000).Wait();
            cts.Cancel();
            try
            {
                task.Wait();
            }
            catch (AggregateException ex)
            {
                Console.WriteLine("Task was cancelled...");
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine("Program completed...");
            Console.ReadKey();
        }
    }
}
