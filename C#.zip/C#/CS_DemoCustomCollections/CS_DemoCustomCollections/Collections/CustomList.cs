﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CS_DemoCustomCollections.Collections
{
    

    internal class CustomList<T>: IEnumerable<T> where T : class, IDisposable, new()
    {
        //private ArrayList store;
        private List<T> store;
        private int count;

        public CustomList(int size)
        {
            //store=new ArrayList(size);
            store = new List<T>(size);
            count = 0;
        }

        public int Count 
        {
            get
            {
                return count;
            }
        }

        public int Capacity
        {
            get
            {
                return store.Capacity;
            }
        }

        //public void Add(object item)
        public void Add(T item)
        {
            store.Add(item);
            count++;
        }

        //public void Remove(object item)
        public void Remove(T item)
        {
            store.Remove(item);
            count--;
        }

        public void Clear()
        {
            store.Clear();
            count = 0;
        }

        //public IEnumerator GetEnumerator()
        //{
        //    return store.GetEnumerator();
        //}

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public IEnumerator<T> GetEnumerator()
        {
            return store.GetEnumerator();
        }

        //public object this[int index]
        public T this[int index]
        {
            get 
            {
                if (index >= 0 && index < store.Count)
                {
                    return store[index];
                }
                else
                {
                    throw new IndexOutOfRangeException($"Index must be >= 0 & < {store.Count}.");
                }
            }
            set 
            {
                if (index >= 0 && index < store.Capacity)
                {
                    store[index] = value;
                }
                else
                {
                    throw new IndexOutOfRangeException($"Index must be >= 0 & < {store.Capacity}.");
                }
            }
        }
    }
}
