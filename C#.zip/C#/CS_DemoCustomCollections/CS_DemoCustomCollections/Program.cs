﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CS_DemoCustomCollections.Collections;

namespace CS_DemoCustomCollections
{
    class Person : IDisposable
    {
        public Person()
        {
            
        }
        public Person(int id)
        {
            
        }
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            //CustomList list = new CustomList(3);
            CustomList<int> list = new CustomList<int>(3);
            CustomList<double> list2 = new CustomList<double>(3);
            CustomList<Person> list3 = new CustomList<Person>(3);
            list.Add(1);
            list.Add(2);
            list.Add(3);
            list.Add(4);
            list[2] = 6;
            Console.WriteLine($"Count: {list.Count}, Capacity: {list.Capacity}");
            Console.WriteLine(list[2]);

            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();
        }
    }
}
