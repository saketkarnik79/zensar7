﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoEnums
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //DaysOfWeek today = DaysOfWeek.Tuesday;
            //Console.WriteLine($"Today is: {today}");
            //Console.WriteLine($"Numeric value of today is: {(int)today}");

            //int dayNumber = 5;
            //DaysOfWeek dayFromNumber = (DaysOfWeek)dayNumber;
            //Console.WriteLine($"Day from number {dayNumber} is: {dayFromNumber}");

            //dayNumber = 15;
            //if (Enum.IsDefined(typeof(DaysOfWeek), dayNumber))
            //{
            //    Console.WriteLine($"{dayNumber} is a valid day number.");
            //}
            //else
            //{
            //    Console.WriteLine($"{dayNumber} is an invalid day number.");
            //}

            //Console.WriteLine();
            //Console.WriteLine("Days of the week:");
            //foreach (string day in Enum.GetNames(typeof(DaysOfWeek)))
            //{
            //    Console.WriteLine(day);
            //}

            FileAccess permissions = FileAccess.Read | FileAccess.Write;
            Console.WriteLine(permissions);

            if ((permissions & FileAccess.Read) == FileAccess.Read)
            {
                Console.WriteLine("Read permission is granted.");
            }

            Console.ReadKey();
        }
    }
}
