﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_DemoEnums
{
    [Flags]
    internal enum FileAccess
    {
        Read = 1, //0001
        Write = 2, //0010
        Execute = 4, //0100
        ReadWrite = Read | Write // 0011
    }
}
