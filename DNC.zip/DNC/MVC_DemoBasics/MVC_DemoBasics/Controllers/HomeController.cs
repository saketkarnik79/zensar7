﻿using Microsoft.AspNetCore.Mvc;
using MVC_DemoBasics.Models;
using System.Diagnostics;

namespace MVC_DemoBasics.Controllers
{
    public class HomeController : Controller
    {
        //public string Index()
        //{
        //    return "<h1 style='color:darkgreen;'>Hello MVC!</h1>";
        //}

        //public ContentResult Index()
        //{
        //    return Content("<h1 style='color:darkgreen;'>Hello MVC!</h1>","text/html");
        //}

        public ViewResult Index()
        {
            ViewData.Add("data1", "Hello! From controller using ViewData!");
            ViewBag.data2 = "Hi! From controller using ViewBag!";
            return View();
        }

        public ViewResult PersonIndex()
        {
            Person p = new Person()
            {
                Id = 1,
                Name = "James",
                Age  = 55
            };

            //ViewData.Model = p;
            //return View();

            return View(p);
        }

        //[HttpPost]
        //public ViewResult PersonIndex(IFormCollection form)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        Person p = new Person()
        //        {
        //            Id = int.Parse(form["Id"]),
        //            Name = form["Name"],
        //            Age = int.Parse(form["Age"])
        //        };
        //        Debug.WriteLine(p);
        //    }
        //    else
        //    {
        //        ModelState.AddModelError(string.Empty, "Invalid data submitted.");
        //    }
        //    return View();
        //}

        [HttpPost]
        public ViewResult PersonIndex([FromForm] Person p)
        {
            if (ModelState.IsValid)
            {
                Debug.WriteLine(p);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid data submitted.");
            }
            return View();
        }
    }
}
