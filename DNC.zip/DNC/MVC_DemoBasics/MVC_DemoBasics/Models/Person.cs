﻿using System.ComponentModel.DataAnnotations;

namespace MVC_DemoBasics.Models
{
    public class Person
    {

        public int Id { get; set; }

        [Display(Name= "Full Person Name")]
        public string Name { get; set; }

        [Display(Name = "Person Age in Years")]
        public int Age { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}, Name: {Name}, Age: {Age}";
        }
    }
}
