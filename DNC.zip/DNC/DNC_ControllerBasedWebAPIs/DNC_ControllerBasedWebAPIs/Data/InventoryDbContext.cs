﻿using Microsoft.EntityFrameworkCore;
using DNC_ControllerBasedWebAPIs.Models;

namespace DNC_ControllerBasedWebAPIs.Data
{
    public class InventoryDbContext: DbContext
    {
        public DbSet<Product> Products { get; set; }

        public InventoryDbContext(DbContextOptions<InventoryDbContext> options): base(options)
        {
            
        }
    }
}
