public class AppSettings
{
    public string AppName {get;set;}
    public string Version {get;set;}
    public int MaxItems {get;set;}
}