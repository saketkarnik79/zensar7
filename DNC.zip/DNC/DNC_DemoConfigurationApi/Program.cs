﻿using Microsoft.Extensions.Configuration;

var configuration=new ConfigurationBuilder()
    .SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile("appSettings.json", optional: false, reloadOnChange: true)
    .Build();
Console.WriteLine($"App Name: {configuration.GetSection("AppSettings").GetValue<string>("AppName")}");
Console.WriteLine($"App Name: {configuration.GetSection("AppSettings").GetValue<string>("Version")}");
Console.WriteLine($"App Name: {configuration.GetSection("AppSettings").GetValue<string>("MaxItems")}");

Console.WriteLine();
Console.WriteLine($"App Name: {configuration["AppSettings:AppName"]}");
Console.WriteLine($"App Name: {configuration["AppSettings:Version"]}");
Console.WriteLine($"App Name: {configuration["AppSettings:MaxItems"]}");

Console.WriteLine();
var appSettings = configuration.GetSection("AppSettings").Get<AppSettings>();
Console.WriteLine($"App Name: {appSettings.AppName}");
Console.WriteLine($"App Name: {appSettings.Version}");
Console.WriteLine($"App Name: {appSettings.MaxItems}");