﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OrdersService.Models;

namespace OrdersService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersApiController : ControllerBase
    {
        private static List<Order> orders = new List<Order>()
        {
            new Order() { OrderId = 1, Product = "Laptop", Quantity = 2},
            new Order() { OrderId = 2, Product = "Smartphone", Quantity = 1}
        };

        [HttpGet]
        public IActionResult GetOrders()
        {
            return Ok(orders);
        }
    }
}
