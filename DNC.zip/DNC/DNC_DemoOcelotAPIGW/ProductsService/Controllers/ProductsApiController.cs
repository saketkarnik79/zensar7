﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProductsService.Models;

namespace ProductsService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsApiController : ControllerBase
    {
        private static List<Product> products = new List<Product>()
        {
            new Product(){ Id =1, Name = "Laptop", Price = 120000 },
            new Product(){ Id =2, Name = "Smartphone", Price = 80000 }
        };

        [HttpGet]
        public IActionResult GetProducts()
        {
            return Ok(products);
        }
    }
}
