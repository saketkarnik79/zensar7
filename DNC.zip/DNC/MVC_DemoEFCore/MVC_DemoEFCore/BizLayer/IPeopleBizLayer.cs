﻿using MVC_DemoEFCore.Models;
using MVC_DemoEFCore.Data;

namespace MVC_DemoEFCore.BizLayer
{
    public interface IPeopleBizLayer
    {
        Task<IEnumerable<Person>> GetPeopleAsync();
        
        Task<IEnumerable<Person>> GetPeopleHavinAgeGreaterThanOrEqualsAsync(int age);

        Task<Person> GetPersonAsync(int id);

        Task AddPersonAsync(Person person);

        Task ModifyPersonAsync(Person person);

        Task RemovePersonAsync(int id);
    }
}
