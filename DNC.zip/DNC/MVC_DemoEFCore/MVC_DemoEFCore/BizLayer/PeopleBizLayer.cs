﻿using MVC_DemoEFCore.Models;
//using MVC_DemoEFCore.Data;
//using Microsoft.EntityFrameworkCore;
using MVC_DemoEFCore.UoW;

namespace MVC_DemoEFCore.BizLayer
{
    public class PeopleBizLayer : IPeopleBizLayer
    {
        //private readonly DemographicsDbContext _demographicsDbContext;
        private readonly IUnitOfWork _unitOfWork;

        //public PeopleBizLayer(DemographicsDbContext demographicsDbContext)
        //{
        //    _demographicsDbContext = demographicsDbContext;
        //}

        public PeopleBizLayer(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task AddPersonAsync(Person person)
        {
            //Some business logic
            
            //_demographicsDbContext.People.Add(person);
            //await _demographicsDbContext.SaveChangesAsync();
            await _unitOfWork.People.AddAsync(person);
            await _unitOfWork.CompleteAsync();

            //Some business logic
        }

        public async Task<IEnumerable<Person>> GetPeopleAsync()
        {
            //Some business logic

            //var result =  await _demographicsDbContext.People.ToListAsync();
            var result = await _unitOfWork.People.GetAllAsync();
            
            //Some business logic
            return result;
        }

        public async Task<IEnumerable<Person>> GetPeopleHavinAgeGreaterThanOrEqualsAsync(int age)
        {
            //Some business logic

            var result = await _unitOfWork.People.FindAllAsync((p) => p.Age >= age);

            //Some business logic
            return result;
        }


        public async Task<Person> GetPersonAsync(int id)
        {
            //Some business logic
            
            //var result = await _demographicsDbContext.People
            //   .SingleOrDefaultAsync(m => m.Id == id);
            var result = await _unitOfWork.People.GetByIdAsync(id);
            
            //Some business logic
            return result;
        }

        public async Task ModifyPersonAsync(Person person)
        {
            //Some business logic
            
            //_demographicsDbContext.Update(person);
            //await _demographicsDbContext.SaveChangesAsync();
            await _unitOfWork.People.UpdateAsync(person);
            await _unitOfWork.CompleteAsync();
            
            //Some business logic
        }

        public async Task RemovePersonAsync(int id)
        {
            //Some business logic

            //var person = await _demographicsDbContext.People.FindAsync(id);
            await _unitOfWork.People.RemoveAsync(id);
            //if (person != null)
            //{
            //    _demographicsDbContext.People.Remove(person);
            //}

            //await _demographicsDbContext.SaveChangesAsync();
            await _unitOfWork.CompleteAsync();

            //Some business logic
        }
    }
}
