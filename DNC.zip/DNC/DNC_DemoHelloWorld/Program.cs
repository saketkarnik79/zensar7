﻿using System;

// See https://aka.ms/new-console-template for more information
namespace DNC_DemoHelloWorld;
class Program
{
    static void Main()
    {
        Console.WriteLine("Hello, World!");
    }
}