﻿using MassTransit;
using OrderService.Models;

namespace OrderService.Messaging
{
    public class OrderPublisher
    {
        private readonly IPublishEndpoint _publishEndpoint;

        public OrderPublisher(IPublishEndpoint publishEndpoint)
        {
            _publishEndpoint = publishEndpoint;
        }

        public async Task PublishOrderAsync(Order order)
        {
            await _publishEndpoint.Publish(order);
        }
    }
}
