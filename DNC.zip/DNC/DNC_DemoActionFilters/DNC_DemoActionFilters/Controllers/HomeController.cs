using DNC_DemoActionFilters.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using DNC_DemoActionFilters.Filters;

namespace DNC_DemoActionFilters.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        //[ResponseCache(Duration = 60, Location = ResponseCacheLocation.Any, NoStore = false)]
        [LoggingActionFilterv2]
        public IActionResult GetData()
        {
            return Ok($"This page is cached at: {DateTime.Now.ToLocalTime()}. This page refreshes at: {DateTime.Now.AddSeconds(60).ToLocalTime()}");
        }

        [TypeFilter(typeof(CustomHeaderFilter), Arguments = new object[] { "x-custom-header", "Sample header value." })]
        public IActionResult Index()
        {
            return View();
        }

        [ServiceFilter(typeof(LoggingActionFilter))]
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
