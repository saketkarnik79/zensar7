﻿using Microsoft.AspNetCore.Mvc.Filters;
using System.Diagnostics;

namespace DNC_DemoActionFilters.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class LoggingActionFilterv2Attribute : Attribute, IActionFilter
    {
        public void OnActionExecuted(ActionExecutedContext context) //Executed After Action Requested
        {
            Debug.WriteLine($"Controller: {context.Controller.GetType().Name}, Action: {context.ActionDescriptor.DisplayName} executed...");
        }

        public void OnActionExecuting(ActionExecutingContext context) //Executed Before Action Requested
        {
            Debug.WriteLine($"Controller: {context.Controller.GetType().Name}, Action: {context.ActionDescriptor.DisplayName} about to execute...");
        }
    }
}
