﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace DNC_DemoActionFilters.Filters
{
    public class CustomHeaderFilter : IActionFilter
    {
        private readonly string _headerName;
        private readonly string _headerValue;

        public CustomHeaderFilter(string headerName, string headerValue)
        {
            _headerName = headerName;
            _headerValue = headerValue;
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {

        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            context.HttpContext.Response.Headers.Add(_headerName, _headerValue);
        }
    }
}
