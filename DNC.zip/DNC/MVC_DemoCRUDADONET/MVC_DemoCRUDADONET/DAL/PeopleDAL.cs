﻿using MVC_DemoCRUDADONET.Models;
using System.Data.SqlClient;

namespace MVC_DemoCRUDADONET.DAL
{
    public class PeopleDAL
    {
        private readonly string cs;

        public PeopleDAL(IConfiguration configuration)
        {
            cs = configuration.GetConnectionString("cs");
        }

        public List<Person> GetPeople()
        {
            List<Person> people = new List<Person>();
            using(SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM People", con);
                
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Person person = new Person()
                    {
                        Id = Convert.ToInt32(reader["ID"]),
                        Name = reader["Name"].ToString(),
                        Age = Convert.ToInt32(reader["Age"])
                    };
                    people.Add(person);
                }
                con.Close();
            };
            return people;
        }

        public Person GetPerson(int id)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                Person p = null;
                SqlCommand cmd = new SqlCommand("SELECT * FROM People WHERE Id = @Id", con);
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    p = new Person()
                    {
                        Id = Convert.ToInt32(reader["ID"]),
                        Name = reader["Name"].ToString(),
                        Age = Convert.ToInt32(reader["Age"])
                    };
                }
                con.Close();
                return p;
            };
        }

        public void CreatePerson(Person p)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("INSERT People VALUES(@Id, @Name, @Age)", con);
                cmd.Parameters.AddWithValue("@Id", p.Id);
                cmd.Parameters.AddWithValue("@Name", p.Name);
                cmd.Parameters.AddWithValue("@Age", p.Age);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            };
        }

        public void UpdatePerson(Person p)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("UPDATE People SET Name = @Name, Age = @Age WHERE Id = @Id", con);
                cmd.Parameters.AddWithValue("@Id", p.Id);
                cmd.Parameters.AddWithValue("@Name", p.Name);
                cmd.Parameters.AddWithValue("@Age", p.Age);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            };
        }

        public void RemovePerson(int id)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("DELETE People WHERE Id = @Id", con);
                cmd.Parameters.AddWithValue("@Id", id);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            };
        }
    }
}