﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVC_DemoCRUDADONET.Models;
using MVC_DemoCRUDADONET.DAL;

namespace MVC_DemoCRUDADONET.Controllers
{
    public class PeopleController : Controller
    {
        private readonly PeopleDAL _dal;

        public PeopleController(PeopleDAL dal)
        {
            _dal = dal;
        }

        // GET: PeopleController
        public ActionResult People()
        {
            return View(_dal.GetPeople());
        }

        // GET: PeopleController/Details/5
        public ActionResult Person(int id)
        {
            return View(_dal.GetPerson(id));
        }

        // GET: PeopleController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PeopleController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([FromForm] Person p)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    //Person p = new Person()
                    //{
                    //    Id = int.Parse(form["Id"]),
                    //    Name = form["Name"],
                    //    Age = int.Parse(form["Age"])
                    //};
                    _dal.CreatePerson(p);
                    return RedirectToAction(nameof(People));
                }
                catch(Exception ex)
                {
                    ModelState.AddModelError(string.Empty, ex.Message);
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid Data.");
                return View();
            }
        }

        // GET: PeopleController/Edit/5
        public ActionResult Edit(int id)
        {
            return View(_dal.GetPerson(id));
        }

        // POST: PeopleController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, [FromForm] Person p)
        {
            if (ModelState.IsValid && id == p.Id)
            {
                try
                {
                    //Person p = new Person()
                    //{
                    //    Id = int.Parse(form["Id"]),
                    //    Name = form["Name"],
                    //    Age = int.Parse(form["Age"])
                    //};
                    _dal.UpdatePerson(p);
                    return RedirectToAction(nameof(People));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, ex.Message);
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid Data.");
                return View();
            }
        }

        // GET: PeopleController/Delete/5
        public ActionResult Delete(int id)
        {
            return View(_dal.GetPerson(id));
        }

        // POST: PeopleController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                _dal.RemovePerson(id);
                return RedirectToAction(nameof(People));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
                return View();
            }
        }
    }
}
