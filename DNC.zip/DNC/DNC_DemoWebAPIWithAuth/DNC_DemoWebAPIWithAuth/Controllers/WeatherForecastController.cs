using DNC_DemoWebAPIWithAuth.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DNC_DemoWebAPIWithAuth.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        [HttpGet("public")]
        public async Task<IActionResult> GetPublicWeather()
        {
            return Ok("This is public weather info.");
        }

        [HttpGet("private")]
        [Authorize]
        public async Task<IActionResult> GetPrivateWeather()
        {
            return Ok("This is private weather info accessible only with a valid JWT.");
        }

        [HttpGet("admin")]
        [Authorize(Roles = "Admins")]
        public async Task<IActionResult> GetAdminWeather()
        {
            return Ok("This is admin-only weather info accessible with a valid JWT having Admins role claim.");
        }
    }
}
