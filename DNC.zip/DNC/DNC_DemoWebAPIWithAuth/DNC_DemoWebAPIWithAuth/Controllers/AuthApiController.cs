﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DNC_DemoWebAPIWithAuth.Services;
using DNC_DemoWebAPIWithAuth.Models;

namespace DNC_DemoWebAPIWithAuth.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthApiController : ControllerBase
    {
        private readonly JwtTokenService _tokenService;

        public AuthApiController(JwtTokenService tokenService)
        {
            _tokenService = tokenService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            if (ModelState.IsValid)
            {
                if (request.UserName == "admin" && request.Password == "P@ssw0rd")
                {
                    var roles = new List<string>() { "Admins" };
                    var token = _tokenService.GenerateToken(request.UserName, roles);
                    return Ok(new { Token = token });
                }
            }
            return Unauthorized("Invalid Credentials!");
        }
    }
}
