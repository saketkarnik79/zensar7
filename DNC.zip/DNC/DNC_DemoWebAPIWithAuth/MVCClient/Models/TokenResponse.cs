﻿namespace MVCClient.Models
{
    public class TokenResponse
    {
        public string Token { get; set; }
    }
}
