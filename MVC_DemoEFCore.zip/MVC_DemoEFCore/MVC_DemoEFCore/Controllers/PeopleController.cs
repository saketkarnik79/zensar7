﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
//using Microsoft.EntityFrameworkCore;
//using MVC_DemoEFCore.Data;
using MVC_DemoEFCore.Models;
using MVC_DemoEFCore.BizLayer;
using Microsoft.AspNetCore.Authorization;

namespace MVC_DemoEFCore.Controllers
{
    [Authorize]
    public class PeopleController : Controller
    {
        //private readonly DemographicsDbContext _context;
        private readonly IPeopleBizLayer _bizLayer;

        //public PeopleController(DemographicsDbContext context)
        //{
        //    _context = context;
        //}

        public PeopleController(IPeopleBizLayer bizLayer)
        {
            _bizLayer = bizLayer;
        }

        // GET: People
        public async Task<IActionResult> People()
        {
            //return View(await _context.People.ToListAsync());
            return View(await _bizLayer.GetPeopleAsync());
        }

        // GET: People/AgeGTE/40
        public async Task<IActionResult> AgeGTE(int id)
        {
            return View(await _bizLayer.GetPeopleHavinAgeGreaterThanOrEqualsAsync(id));
        }

        // GET: People/Details/5
        public async Task<IActionResult> Person(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var person = await _context.People
            //    .SingleOrDefaultAsync(m => m.Id == id);

            var person = await _bizLayer.GetPersonAsync(id.Value);

            if (person == null)
            {
                return NotFound();
            }

            return View(person);
        }

        // GET: People/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: People/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Age")] Person person)
        {
            if (ModelState.IsValid)
            {
                //_context.People.Add(person);
                //await _context.SaveChangesAsync();

                await _bizLayer.AddPersonAsync(person);

                return RedirectToAction(nameof(People));
            }
            return View(person);
        }

        // GET: People/Edit/5
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var person = await _context.People.FindAsync(id);
            var person = await _bizLayer.GetPersonAsync(id.Value);

            if (person == null)
            {
                return NotFound();
            }
            return View(person);
        }

        // POST: People/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, Person person)
        {
            if (id != person.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    //_context.Update(person);
                    //await _context.SaveChangesAsync();
                    await _bizLayer.ModifyPersonAsync(person);
                }
                catch (Exception)
                {
                    if (!PersonExists(person.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(People));
            }
            return View(person);
        }

        // GET: People/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var person = await _context.People
            //    .FirstOrDefaultAsync(m => m.Id == id);

            var person = await _bizLayer.GetPersonAsync(id.Value);

            if (person == null)
            {
                return NotFound();
            }

            return View(person);
        }

        // POST: People/Delete/5
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            //var person = await _context.People.FindAsync(id);
            await _bizLayer.RemovePersonAsync(id);
            //if (person != null)
            //{
            //    _context.People.Remove(person);
            //}

            //await _context.SaveChangesAsync();
            return RedirectToAction(nameof(People));
        }

        private bool PersonExists(int id)
        {
            //return _context.People.Any(e => e.Id == id);
            return _bizLayer.GetPersonAsync(id) != null;
        }
    }
}
