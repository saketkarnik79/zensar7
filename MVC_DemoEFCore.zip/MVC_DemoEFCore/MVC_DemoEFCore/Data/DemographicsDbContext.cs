﻿using Microsoft.EntityFrameworkCore;
using MVC_DemoEFCore.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace MVC_DemoEFCore.Data
{
    public class DemographicsDbContext: IdentityDbContext<IdentityUser>
    {
        public DbSet<Person> People { get; set; }

        public DemographicsDbContext(DbContextOptions<DemographicsDbContext> options):base(options)
        {
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseInMemoryDatabase("Demographics");
            }
        }
    }
}
