﻿using MVC_DemoEFCore.Models;
using MVC_DemoEFCore.Data;
using MVC_DemoEFCore.Repositories;

namespace MVC_DemoEFCore.UoW
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DemographicsDbContext _demographicsDbContext;

        public UnitOfWork(DemographicsDbContext demographicsDbContext)
        {
            _demographicsDbContext = demographicsDbContext;
            People = new Repository<Person>(_demographicsDbContext);
        }

        public IRepository<Person> People { get; }

        public async Task<int> CompleteAsync() => await _demographicsDbContext.SaveChangesAsync();

        public void Dispose()
        {
            _demographicsDbContext.DisposeAsync().AsTask().Wait();
        }
    }
}
