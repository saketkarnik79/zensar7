﻿using MVC_DemoEFCore.Models;
using MVC_DemoEFCore.Repositories;

namespace MVC_DemoEFCore.UoW
{
    public interface IUnitOfWork: IDisposable
    {
        IRepository<Person> People { get; }
        Task<int> CompleteAsync();
    }
}
